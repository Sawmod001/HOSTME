---
applyTo: "src/components/**/*.jsx"
---

# Component conventions

- Use design tokens from `docs/HostMe_Design_System.md` — never hardcode hex colors or font sizes inline; use the Tailwind theme extension mapped to those CSS variables.
- Every component that fetches or mutates data must implement all four states: loading (skeleton matching final layout), empty, error (with retry action), and pessimistic-disabled (instant lock on click, per the Pessimistic UI NFR).
- Mobile-first: write the unprefixed Tailwind classes for mobile layout, add `lg:` overrides for desktop. Never the reverse.
- Status colors are fixed by meaning, not reused: red (`--color-danger`) is reserved exclusively for `disputed` bookings. Cancelled/rejected use `--color-neutral-status` (grey).
- Shared booking UI (`/components/booking`) must branch on `bookingType` explicitly (`capacity` vs `exclusive`) rather than trying to build one universal component that handles both — they have different states, different copy, and different user actions.
