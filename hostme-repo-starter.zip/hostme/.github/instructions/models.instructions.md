---
applyTo: "src/models/**/*.js"
---

# Model conventions

- All money fields are integers in Kobo — never Number with decimals, never a Mongoose Decimal128 unless explicitly asked.
- Every model that participates in booking concurrency (`Slot`, `ExclusiveLock`) must expose its atomic update pattern as a named function in the same file, not inline in API routes — keeps the atomic logic in one reviewable place. See `docs/HostMe_Database_Schemas_v2.md` for the exact patterns to replicate.
- Compound indexes go directly under the schema definition, with a one-line comment explaining which query pattern they serve.
- Use `mongoose.models.X || mongoose.model('X', XSchema)` export guard everywhere — Next.js hot-reload will otherwise throw "Cannot overwrite model" errors.
